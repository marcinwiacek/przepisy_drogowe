
$(document).bind("mobileinit", function(){
	$.mobile.page.prototype.options.addBackBtn= false;
});	
